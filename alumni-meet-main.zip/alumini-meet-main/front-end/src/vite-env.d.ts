/// <reference types="vite/client" />
declare module "random-hex-color"